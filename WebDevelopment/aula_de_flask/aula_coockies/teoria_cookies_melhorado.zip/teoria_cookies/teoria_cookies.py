from flask import Flask, request, render_template, make_response


app = Flask(__name__)

# Quando eu fiz o login, o site me forneceu uma string, chamada "cookie"
# Toda vez que eu clico num link, o site precisa me validar, saber se sou eu mesmo.
# Ele faz isso conferindo essa string "cookie", que eu mando com toda requisição
# Se eu for em outro navegador, e pedir pra ele mandar o mesmo cookie a cada 
# requisição, o site vai achar que sou eu

# Qual foi a roubada que eu te ensinei:
# 1) foi no navegador logado, no console javascript, e pegou o conteudo da
# variavel document.cookie
# 2) Colocou essa mesma variavel no seu navegador
# 3) Quando voce manda uma requisição pro site, ele valida e acha que sou eu

'''
Originalmente, cookies eram usados para ajudar o usuário.

Manter uma sessão aberta pro usuário poder fazer compras, por exemplo

Hoje em dia, tb se usa muito para fins publicitários
O site manda um cookie, e o navegador fica mandando de volta...
Sem saber, a pessoa está construindo um histórico no site.

Pior ainda, as vezes a gente acessa um site e o outro "espiona"
Acesso www.pudim.com.br
 baixa um html
 nesse html eu posso ter outros arquivos pra baixar, css, js
 um desses js pode vir do google
 como o js vem do google, toda vez que eu baixo o js eu mando o cookie do google
'''

@app.route("/")
def start():
    return "Acesse a url /ola1"

@app.route("/ola1")
def ola1():
    return render_template("ola1.html")
'''
<form action="/ola2">
    <input type="text" name="login"> 
    <input type="submit" value="entrar">
</form>
Ola1 é um form que submete
a variavel login para ola2
action diz que é para ola2
nome da variavel é o name="login"

O form usa o verbo GET. Como eu nao especifiquei nada, ele usou
o GET, que é padrão
'''


@app.route("/ola2")
def ola2():
    if 'login' in request.args.keys():   #a variavel que eu mandei no form vem parar nesse
                                         #dicionário request.args
        valor_login = request.args['login']

    response = make_response(  render_template("ola2.html",pessoa=valor_login)  )
    # o render template normalmente era uma coisa que eu retornava...
    # mas agora, eu usei esse make_response, pra poder colocar mais coisas além da página html
    response.set_cookie('login',valor_login)
    #minha reposta agora tem um cookie, além do texto
    # o navegador vai receber um set-cookie, e começar a me enviar 
    # o header cookie a cada request    
    
    return response


@app.route("/ola3")
def ola3():
    if 'login' in request.cookies:
        valor_login = request.cookies['login']
    #aqui está o cookie que o usuário enviou
    
    return render_template("ola2.html",pessoa=valor_login) 

if __name__ == '__main__':
    app.run(debug=True)